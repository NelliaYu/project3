-- 웹프로젝트 디비파일


--이용시간 안내 이번달 데이터 뷰
create or replace view vwInfoGuide
as
select * from tblInfoGuide where substr(guide_date, 0, 8) between trunc(sysdate,'MM') and (last_day(sysdate));



--메인 대출베스트 뷰
create or replace view vwMainBest
as
select 
    p.book_seq, b.book_subject, b.book_author, count(p.lending_seq) as book_count
from tblPresent p
inner join tblBook b
on p.book_seq = b.book_seq
where p.lending_date between sysdate - 7 and sysdate
group by p.book_seq, b.book_subject, b.book_author order by count(p.lending_seq) desc;



--도서 테이블 일반 도서 개수 구하기
create or replace view vwNormalBookCount
as
select book_genre, count(book_genre) as book_count from tblBook where book_position = '종합자료실' group by book_genre order by book_genre;

select * from vwNormalBookCount;



--도서 테이블 어린이 도서 개수 구하기
create or replace view vwChildrenBookCount
as
select book_genre, count(book_genre) as book_count from tblBook where book_position = '어린이자료실' group by book_genre order by book_genre;


--도서 테이블 전체 도서 개수 구하기
create or replace view vwBookCount
as
select book_genre, count(book_genre) as book_count from tblBook group by book_genre order by book_genre;




--어린이자료실 이용시간
create or replace view vwInFacilChildrenTime
as
select 
    ift.faciltime_seq,
    if.facil_position,
    ift.faciltime_day,
    ift.faciltime_time
from tblInFacil if
inner join tblInFacilTime ift
    on if.facil_seq = ift.facil_seq
where if.facil_position = '어린이자료실';


--디지털자료실 이용시간
create or replace view vwInFacilDigitalTime
as
select 
    ift.faciltime_seq,
    if.facil_position,
    ift.faciltime_day,
    ift.faciltime_time
from tblInFacil if
inner join tblInFacilTime ift
    on if.facil_seq = ift.facil_seq
where if.facil_position = '디지털자료실';


--종합자료실 이용시간
create or replace view vwInFacilTotalTime
as
select 
    ift.faciltime_seq,
    if.facil_position,
    ift.faciltime_day,
    ift.faciltime_time
from tblInFacil if
inner join tblInFacilTime ift
    on if.facil_seq = ift.facil_seq
where if.facil_position = '종합자료실';




select * from vwInDataGraph;

--월별 장서 증가 추이
create or replace view vwInDataGraph
as
select book_regdate, count(book_regdate) as book_count from tblBook group by book_regdate order by book_regdate;



